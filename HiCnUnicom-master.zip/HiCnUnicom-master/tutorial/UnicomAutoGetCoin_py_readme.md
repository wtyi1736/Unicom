### UnicomGetCoin.py
作者： https://github.com/QiuYueBaiJXW

#联通营业厅签到领积分

#新增七日4GB流量包获取


#使用方法

  一、自己挂服务器

        只需下载py文件，将py文件倒数第二行引号中的内容按照提示抓包替换即可。
  
  二、利用github的workflow自动运行
   
   如需使用该方法，请前往[@QiuYueBaiJXW/UnicomGetCoin](https://github.com/QiuYueBaiJXW/UnicomGetCoin)
 
 #抓包方法及内容
    
    退出手机营业厅登录，然后开启抓包软件，登录手机营业厅
    
    查找网址为 https://m.client.10010.com/mobileService/login.htm 的记录，找到请求内容，将&sim开始到最后的内容按要求填入py文件。
    
    具体内容见下图
    
   ![Image Text](https://github.com/QiuYueBaiJXW/UnicomGetCoin/blob/master/Photo/A86CC0F6-E719-47C2-9087-AA428FC88C00.jpeg?raw=true)
  
  
    
 #无限期To Do
 
     1.每日自动抽奖三次
     
     2.改进登录方式，取消抓包登录，改用账号密码登录
     
     3.sh版本的其他功能比如沃之树等等
 
 #感谢
    
   [@mixool](https://github.com/mixool/)
    
    感谢@mixool将py版本纳入其中，sh版本的其他功能列入无限期 To do
    
  #免责申明
    
    该项目仅供学习使用，严禁用于商业用途，由此造成的一切后果，本人概不负责。
