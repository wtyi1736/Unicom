> 中国联通APP登录 签到 金币 任务 解流量封顶

#### 各版本使用教程  
> [**CnUnicom.sh**](https://github.com/mixool/HiCnUnicom/blob/master/tutorial/CnUnicom_sh_readme.md)  
> [**UnicomGetCoin.py**](https://github.com/mixool/HiCnUnicom/blob/master/tutorial/UnicomAutoGetCoin_py_readme.md)  
> [**使用github自动运行，无需自己的服务器**](https://github.com/hzys/HiCnUnicom)  
